/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { logOut } from "../feature/AuthSlice";
import { liste_vile } from "../page/Register";
import { isEmpty } from "./Utils";

const AreaSearch = () => {
  const dispatch = useDispatch();
  let nav = useNavigate();
  const user = useSelector((t) => t.auth.user);
  const [ville, setville] = useState("");
  const [notesearch, setnotesearch] = useState("");
  const [ifville, setIfville] = useState(false);

  const logout = () => {
    window.location.href = "/accueil";
    dispatch(logOut([]));
  };

  const recherche = () => {
    if (notesearch === "" && ville === "") {
      nav(`/search/ville/parameter`);
    } else if (notesearch !== "" && ville === "") {
      nav(`/search/ville/${notesearch}`);
    } else if (notesearch === "" && ville !== "") {
      nav(`/search/${ville}/parameter`);
    } else if (notesearch !== "" && ville !== "") {
      nav(`/search/${ville}/${notesearch}`);
    }
  };
  
  return (
    <>
      <div className="accueil2">
        <div className="text-center mb-3 text-black font-semibold text-3xl">
          <span>Trouver un prestataire</span>
        </div>
        <div className="flex items-center justify-center space-x-1 flex-wrap text-center container recher">
          <div className="w-80">
            <input
              className="border-2 border-color rounded-lg pl-2 text-xl h-10 w-80 text-black"
              list="datalistOptions"
              id="exampleDataList"
              placeholder="Ex: Menusier"
              onChange={(e) => {
                setnotesearch(e.target.value);
              }}
            />
          </div> 
          <div className="mt-2">
            <select
              name="ville"
              id="ville"
              onChange={(e) => {
                setville(e.target.value);
              }}
              className="form-select"
            >
              <option value="">Votre ville</option>
              {liste_vile[0] &&
                liste_vile.map((val) => {
                  return (
                    <option value={val.nom} key={val.id}>
                      {val.nom}
                    </option>
                  );
                })}
            </select>
            {/* {ifville && (
                  <div className="empty_full">
                    Veuillez choisir votre ville !
                  </div>)} */}
          </div>
        </div>
        <div className="text-center mt-3">
          {/* <Link to={"/search"}> */}
            <button type="button" className="btn btn-light" onClick={()=>{recherche()}}>
              Lancer la recherche
            </button>
          {/* </Link> */}
          {/* <button type="button" className="btn btn-light" >Lancer la recherche</button> */}
        </div>
        {/* {!isEmpty(user) && (
          <>
            <button
              onClick={logout}
              className="bg-amber-300 px-4 py-2 rounded-sm mr-2"
            >
              LogOut
            </button>
            <button
              onClick={() => nav(`/profile/${user.userId}/${user.professionId}`)}
              className="bg-amber-300 px-4 py-2 rounded-sm"
            >
              Mon Profile
            </button>
          </>
        )} */}
      </div>
    </>
  );
};

export default AreaSearch;
